This is a MANGOS (TrinityDB) to WOWEMU creature parser!
BEFORE STARTING MAKE SURE YOU OPENED PARSER.CONF
AND CONFIGURED IT!.. This is a typical "connection-string" (google),
use your favorites. MySQL ODBC 3.51 Connector is highly recommended, 
and is pre-configured. Set your username/pass/IP/port and your done.

--------------------- NOTE TO RIFT DEVELOPERS: --------------------------
This is EASILY modifiable to any future structure ever made
for RIFT's creatures database.
------------------------------------------------------------------------------------------------