Converts the list of opcodes in 'list.txt' to a useable list in 'cmsg.txt' and 'smsg.txt'. Just look for an example.
This was needed in early development, probably won't ever be needed again - in the event it is, here it sits.
It's not meant to be compiled (necessarily), just run it in the VB IDE.